@php
    $currentStationUrl = \App\Models\SiteSetting::get('stream_url', env('STREAM_URL', 'default'));
    $currentStationName = config('app.name', 'station');
    $stationId = 'st_' . substr(md5($currentStationUrl . '_' . $currentStationName), 0, 10);
@endphp
    <script>
        // Inline Promise polyfill for legacy Safari / older iOS engines
        if (typeof window.Promise === 'undefined') {
            window.Promise = function(fn) {
                var callbacks = [];
                var errCallbacks = [];
                var state = 'pending';
                var value;
                this.then = function(onSuccess, onError) {
                    if (state === 'fulfilled') {
                        if (onSuccess) try { onSuccess(value); } catch(e) {}
                    } else if (state === 'rejected') {
                        if (onError) try { onError(value); } catch(e) {}
                    } else {
                        if (onSuccess) callbacks.push(onSuccess);
                        if (onError) errCallbacks.push(onError);
                    }
                    return this;
                };
                this.catch = function(onError) {
                    return this.then(null, onError);
                };
                function resolve(val) {
                    state = 'fulfilled';
                    value = val;
                    for (var i = 0; i < callbacks.length; i++) {
                        try { callbacks[i](val); } catch(e) {}
                    }
                }
                function reject(err) {
                    state = 'rejected';
                    value = err;
                    for (var i = 0; i < errCallbacks.length; i++) {
                        try { errCallbacks[i](err); } catch(e) {}
                    }
                }
                try { if (typeof fn === 'function') fn(resolve, reject); } catch(e) { reject(e); }
            };
            window.Promise.resolve = function(val) {
                return new window.Promise(function(res) { res(val); });
            };
            window.Promise.reject = function(err) {
                return new window.Promise(function(res, rej) { rej(err); });
            };
        }

        // Element.closest & matches polyfills for older Safari / legacy WebKit engines
        if (typeof window.Element !== 'undefined') {
            if (!Element.prototype.matches) {
                Element.prototype.matches = Element.prototype.matchesSelector ||
                    Element.prototype.mozMatchesSelector ||
                    Element.prototype.msMatchesSelector ||
                    Element.prototype.oMatchesSelector ||
                    Element.prototype.webkitMatchesSelector ||
                    function(s) {
                        var matches = (this.document || this.ownerDocument).querySelectorAll(s),
                            i = matches.length;
                        while (--i >= 0 && matches.item(i) !== this) {}
                        return i > -1;
                    };
            }
            if (!Element.prototype.closest) {
                Element.prototype.closest = function(s) {
                    var el = this;
                    do {
                        if (el.matches && el.matches(s)) return el;
                        el = el.parentElement || el.parentNode;
                    } while (el !== null && el.nodeType === 1);
                    return null;
                };
            }
        }

        window.CURRENT_STATION_ID = @json($stationId);
        window.getStationStorageKey = function(key) {
            return 'station_' + window.CURRENT_STATION_ID + '_' + key;
        };

        var RadioAudio = (function() {
            var _el = null;
            return {
                get: function() {
                    if (_el && document.body && document.body.contains(_el)) {
                        return _el;
                    }
                    _el = document.getElementById('live-audio');
                    return _el;
                },
                reset: function() {
                    _el = null;
                },
                paused: function() {
                    var a = this.get();
                    if (!a || typeof a.play !== 'function') return true;
                    return a.paused;
                },
                play: function() {
                    var a = this.get();
                    if (!a || typeof a.play !== 'function') {
                        return (typeof window.Promise !== 'undefined' ? Promise.resolve() : undefined);
                    }
                    try {
                        var p = a.play();
                        if (p && typeof p.then === 'function') {
                            return p;
                        }
                        return (typeof window.Promise !== 'undefined' ? Promise.resolve() : undefined);
                    } catch (e) {
                        return (typeof window.Promise !== 'undefined' ? Promise.reject(e) : undefined);
                    }
                },
                pause: function() {
                    var a = this.get();
                    if (a && typeof a.pause === 'function') {
                        try {
                            a.pause();
                        } catch (e) {}
                    }
                },
                setSrc: function(src) {
                    var a = this.get();
                    if (a) {
                        a.src = src;
                        var source = a.querySelector ? a.querySelector('source') : null;
                        if (source) source.src = src;
                    }
                },
                load: function() {
                    var a = this.get();
                    if (a && typeof a.load === 'function') {
                        try {
                            a.load();
                        } catch (e) {}
                    }
                },
                getVolume: function() {
                    var a = this.get();
                    return (a && typeof a.volume !== 'undefined') ? a.volume : 1;
                }
            };
        })();

        // Continuous Background AVAudioSession Keep-Alive Bridge for iOS Safari / Android Chrome / CarPlay / Bluetooth
        // Plays an in-memory (RAM blob:) sub-audible PCM loop (-130 dBFS, 18Hz non-zero samples) alongside a WebAudio oscillator
        // so when Cellular Data or Bluetooth/CarPlay drops while navigating in Google Maps (background tab),
        // iOS mediaserverd NEVER suspends the background Safari tab and NEVER revokes background audio.play() permission.
        window.BgAudioBridge = (function() {
            var _keepAliveEl = null;
            var _wavBlobUrl = null;
            var _audioCtx = null;
            var _osc = null;
            var _gain = null;
            var _lastClockTick = 0;

            function createSubAudibleWavBlobUrl() {
                if (_wavBlobUrl) return _wavBlobUrl;
                try {
                    var sampleRate = 8000;
                    var durationSeconds = 4;
                    var numSamples = sampleRate * durationSeconds;
                    var dataSize = numSamples * 2;
                    var buffer = new ArrayBuffer(44 + dataSize);
                    var view = new DataView(buffer);

                    function writeString(offset, str) {
                        for (var i = 0; i < str.length; i++) {
                            view.setUint8(offset + i, str.charCodeAt(i));
                        }
                    }

                    writeString(0, 'RIFF');
                    view.setUint32(4, 36 + dataSize, true);
                    writeString(8, 'WAVE');
                    writeString(12, 'fmt ');
                    view.setUint32(16, 16, true);
                    view.setUint16(20, 1, true); // PCM
                    view.setUint16(22, 1, true); // Mono
                    view.setUint32(24, sampleRate, true);
                    view.setUint32(28, sampleRate * 2, true);
                    view.setUint16(32, 2, true);
                    view.setUint16(34, 16, true);
                    writeString(36, 'data');
                    view.setUint32(40, dataSize, true);

                    // Write non-zero sub-audible (+/- 2 LSB at 18 Hz) samples so iOS 16/17/18 silence detector treats as active audio
                    var twoPiF = 2 * Math.PI * 18 / sampleRate;
                    for (var s = 0; s < numSamples; s++) {
                        var sampleVal = Math.round(Math.sin(s * twoPiF) * 2);
                        if (sampleVal === 0) sampleVal = (s % 2 === 0) ? 1 : -1;
                        view.setInt16(44 + s * 2, sampleVal, true);
                    }

                    var blob = new Blob([buffer], { type: 'audio/wav' });
                    _wavBlobUrl = URL.createObjectURL(blob);
                    return _wavBlobUrl;
                } catch (e) {
                    return 'data:audio/wav;base64,UklGRigAAABXQVZFZm10IBIAAAABAAEARKwAAIhYAQACABAAAABkYXRhAgAAAAEA';
                }
            }

            function ensureKeepAliveElement() {
                if (_keepAliveEl && document.body && document.body.contains(_keepAliveEl)) {
                    return _keepAliveEl;
                }
                _keepAliveEl = document.getElementById('bg-keepalive-audio');
                if (!_keepAliveEl && document.body) {
                    _keepAliveEl = document.createElement('audio');
                    _keepAliveEl.id = 'bg-keepalive-audio';
                    _keepAliveEl.loop = true;
                    _keepAliveEl.preload = 'auto';
                    _keepAliveEl.volume = 0.005;
                    _keepAliveEl.setAttribute('playsinline', '');
                    _keepAliveEl.setAttribute('webkit-playsinline', '');
                    _keepAliveEl.style.display = 'none';
                    _keepAliveEl.src = createSubAudibleWavBlobUrl();
                    document.body.appendChild(_keepAliveEl);

                    // Hardware-clocked background heartbeat driven by CoreAudio even when Safari is behind Google Maps
                    _keepAliveEl.addEventListener('timeupdate', function() {
                        var now = Date.now();
                        if (now - _lastClockTick >= 1400) {
                            _lastClockTick = now;
                            if (typeof window._runBgWatchdogTick === 'function') {
                                window._runBgWatchdogTick('keepalive-audio-clock');
                            }
                        }
                    });

                    // If iOS briefly pauses keep-alive during a route change or cellular blip while intent is valid, auto-resume it immediately
                    _keepAliveEl.addEventListener('pause', function() {
                        if (!window.userPaused && typeof window.isIntentStillValid === 'function' && window.isIntentStillValid()) {
                            setTimeout(function() {
                                if (!window.userPaused && window.isIntentStillValid() && _keepAliveEl && _keepAliveEl.paused) {
                                    try { _keepAliveEl.play().catch(function() {}); } catch (e) {}
                                }
                            }, 80);
                            setTimeout(function() {
                                if (!window.userPaused && window.isIntentStillValid() && _keepAliveEl && _keepAliveEl.paused) {
                                    try { _keepAliveEl.play().catch(function() {}); } catch (e) {}
                                }
                            }, 450);
                        }
                    });
                }
                return _keepAliveEl;
            }

            function ensureWebAudioBridge() {
                try {
                    var AudioCtx = window.AudioContext || window.webkitAudioContext;
                    if (!AudioCtx) return;
                    if (!_audioCtx) {
                        _audioCtx = new AudioCtx();
                        _gain = _audioCtx.createGain();
                        _gain.gain.value = 0.00001;
                        _osc = _audioCtx.createOscillator();
                        _osc.frequency.value = 18;
                        _osc.connect(_gain);
                        _gain.connect(_audioCtx.destination);
                        try { _osc.start(0); } catch (e) {}

                        _audioCtx.onstatechange = function() {
                            if (!_audioCtx) return;
                            console.log('🔊 [BgAudioBridge] AudioContext state changed to:', _audioCtx.state);
                            if (_audioCtx.state === 'running') {
                                // Hardware audio route (Bluetooth / CarPlay / Phone call) interruption just ended in background!
                                if (!window.userPaused && typeof window.isIntentStillValid === 'function' && window.isIntentStillValid()) {
                                    if (typeof window.setAudioInterrupted === 'function') {
                                        window.setAudioInterrupted(false);
                                    }
                                    var live = RadioAudio.get();
                                    if (live && (live.paused || live.error || live.readyState < 2)) {
                                        if (typeof window.recoverLiveStream === 'function') {
                                            window.recoverLiveStream('audioctx-route-restored');
                                        }
                                    }
                                }
                            } else if ((_audioCtx.state === 'interrupted' || _audioCtx.state === 'suspended') && !window.userPaused && typeof window.isIntentStillValid === 'function' && window.isIntentStillValid()) {
                                // Periodically attempt to resume AudioContext in background so as soon as BT/CarPlay reconnects, state returns to running
                                setTimeout(function() {
                                    if (_audioCtx && _audioCtx.state !== 'running' && !window.userPaused && window.isIntentStillValid()) {
                                        try { _audioCtx.resume().catch(function() {}); } catch (e) {}
                                    }
                                }, 1200);
                            }
                        };
                    }
                    if (_audioCtx && _audioCtx.state !== 'running') {
                        try { _audioCtx.resume().catch(function() {}); } catch (e) {}
                    }
                } catch (e) {}
            }

            return {
                start: function() {
                    var el = ensureKeepAliveElement();
                    if (el) {
                        if (!el.src) el.src = createSubAudibleWavBlobUrl();
                        el.volume = 0.005;
                        if (el.paused) {
                            try { el.play().catch(function() {}); } catch (e) {}
                        }
                    }
                    ensureWebAudioBridge();
                },
                ensurePlaying: function() {
                    if (window.userPaused || (typeof window.isIntentStillValid === 'function' && !window.isIntentStillValid())) {
                        return;
                    }
                    var el = ensureKeepAliveElement();
                    if (el && el.paused) {
                        try { el.play().catch(function() {}); } catch (e) {}
                    }
                    if (_audioCtx && _audioCtx.state !== 'running') {
                        try { _audioCtx.resume().catch(function() {}); } catch (e) {}
                    }
                },
                stop: function() {
                    if (_keepAliveEl && !_keepAliveEl.paused) {
                        try { _keepAliveEl.pause(); } catch (e) {}
                    }
                    if (_audioCtx && _audioCtx.state === 'running' && typeof _audioCtx.suspend === 'function') {
                        try { _audioCtx.suspend().catch(function() {}); } catch (e) {}
                    }
                },
                isActive: function() {
                    return !!(_keepAliveEl && !_keepAliveEl.paused);
                }
            };
        })();
    </script>
    <script>
        // Private / Incognito browsing safe storage polyfill (in-memory fallback)
        if (!window.safeLocalStorage) {
            var _memStorageMap = {};
            window.safeLocalStorage = {
                getItem: function(key) {
                    try { return window.localStorage.getItem(key); } catch(e) { return _memStorageMap[key] || null; }
                },
                setItem: function(key, val) {
                    try { window.localStorage.setItem(key, val); } catch(e) { _memStorageMap[key] = String(val); }
                },
                removeItem: function(key) {
                    try { window.localStorage.removeItem(key); } catch(e) { delete _memStorageMap[key]; }
                },
                clear: function() {
                    try { window.localStorage.clear(); } catch(e) { _memStorageMap = {}; }
                }
            };
        }
        if (!window.safeSessionStorage) {
            var _memSessionMap = {};
            window.safeSessionStorage = {
                getItem: function(key) {
                    try { return window.sessionStorage.getItem(key); } catch(e) { return _memSessionMap[key] || null; }
                },
                setItem: function(key, val) {
                    try { window.sessionStorage.setItem(key, val); } catch(e) { _memSessionMap[key] = String(val); }
                },
                removeItem: function(key) {
                    try { window.sessionStorage.removeItem(key); } catch(e) { delete _memSessionMap[key]; }
                },
                clear: function() {
                    try { window.sessionStorage.clear(); } catch(e) { _memSessionMap = {}; }
                }
            };
        }

        // Station-isolated audio persistence functionality (ES5 Compatible)
        function AudioPersistenceManager() {
            this.storageKey = window.getStationStorageKey('audio_state');
            this.tabId = this.generateTabId();
            this.isActiveTab = true;
            this.init();
        }

        AudioPersistenceManager.prototype.generateTabId = function() {
            return 'tab_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
        };

        AudioPersistenceManager.prototype.init = function() {
            var self = this;
            try {
                window.safeLocalStorage.setItem(this.storageKey + '_current_tab', this.tabId);
            } catch(e) {}

            window.addEventListener('storage', function(e) {
                if (e.key === self.storageKey) {
                    self.handleAudioStateChange(JSON.parse(e.newValue || '{}'));
                } else if (e.key === self.storageKey + '_current_tab') {
                    self.handleTabChange(e.newValue);
                }
            });

            document.addEventListener('visibilitychange', function() {
                var isPlaying = window.isRealAudioPlaying ? window.isRealAudioPlaying() : (audio && !audio.paused);
                if (document.hidden) {
                    if (!isPlaying) {
                        self.isActiveTab = false;
                    }
                } else {
                    self.isActiveTab = true;
                    try {
                        window.safeLocalStorage.setItem(self.storageKey + '_current_tab', self.tabId);
                    } catch(e) {}
                    self._syncVolumeOnly();

                    // Check and verify audio health immediately on foreground return
                    if (typeof window.verifyStreamHealthOnForeground === 'function') {
                        window.verifyStreamHealthOnForeground('visibilitychange');
                    }
                }
            });

            window.addEventListener('focus', function() {
                self.isActiveTab = true;
                try {
                    window.safeLocalStorage.setItem(self.storageKey + '_current_tab', self.tabId);
                } catch(e) {}
                self._syncVolumeOnly();

                if (typeof window.verifyStreamHealthOnForeground === 'function') {
                    window.verifyStreamHealthOnForeground('focus');
                }
            });

            window.addEventListener('blur', function() {
                var isPlaying = window.isRealAudioPlaying ? window.isRealAudioPlaying() : false;
                if (!isPlaying) {
                    self.isActiveTab = false;
                }
            });

            window.addEventListener('beforeunload', function() {
                try {
                    window.safeLocalStorage.setItem(window.getStationStorageKey('tab_closed_at'), Date.now().toString());
                } catch(e) {}
                self.saveAudioState();
            });
        };

        AudioPersistenceManager.prototype.handleAudioStateChange = function(state) {
            if (!this.isActiveTab) return;
            var audio = RadioAudio.get();
            if (!audio) return;

            if (state && state.volume !== undefined) {
                audio.volume = state.volume;
            }
            this.updatePlayPauseIcons(window.isRealAudioPlaying ? window.isRealAudioPlaying() : !audio.paused);
        };

        AudioPersistenceManager.prototype._syncVolumeOnly = function() {
            try {
                var saved = JSON.parse(window.safeLocalStorage.getItem(this.storageKey) || '{}');
                var audio = RadioAudio.get();
                if (audio && saved.volume !== undefined) {
                    audio.volume = saved.volume;
                }
            } catch (e) {}
        };

        AudioPersistenceManager.prototype.handleTabChange = function(activeTabId) {
            this.isActiveTab = (activeTabId === this.tabId);
        };

        AudioPersistenceManager.prototype.saveAudioState = function() {
            var audio = RadioAudio.get();
            if (!audio) return;

            var state = {
                isPlaying: window.isRealAudioPlaying ? window.isRealAudioPlaying() : !audio.paused,
                volume: audio.volume,
                currentTime: audio.currentTime,
                timestamp: Date.now()
            };

            try {
                window.safeLocalStorage.setItem(this.storageKey, JSON.stringify(state));
            } catch(e) {}
        };

        window.PLAYER_STATE = {
            IDLE: 'idle',
            LOADING: 'loading',
            PLAYING: 'playing',
            PAUSED: 'paused',
            RECONNECTING: 'reconnecting',
            ERROR: 'error'
        };
        window._currentPlayerState = window.PLAYER_STATE.IDLE;

        // Evaluates genuine media state - NEVER relies solely on audio.paused === false
        window.isRealAudioPlaying = function() {
            var audio = RadioAudio.get();
            if (!audio) return false;
            if (audio.paused || audio.ended || audio.error) return false;
            if (typeof _isRecovering !== 'undefined' && _isRecovering) return false;
            // In HTML5 audio, readyState >= 2 (HAVE_CURRENT_DATA) is required for real audio playback
            return (audio.readyState >= 2);
        };

        // ── Stream Reconnecting Dialogue & Alert Banner Controller ──
        window.showReconnectingDialogue = function(title, message, state) {
            var dlg = document.getElementById('stream-reconnecting-dialogue');
            if (!dlg) return;
            var titleEl = document.getElementById('srd-title');
            var msgEl   = document.getElementById('srd-message');
            var iconEl  = document.getElementById('srd-icon');
            var retryBtn = document.getElementById('srd-retry-btn');

            if (titleEl && title) titleEl.textContent = title;
            if (msgEl && message) msgEl.textContent = message;

            dlg.classList.remove('srd-success', 'srd-offline');
            clearTimeout(dlg._hideTimer);

            if (state === 'success') {
                dlg.classList.add('srd-success');
                if (iconEl) iconEl.className = 'fas fa-check-circle srd-icon text-success';
                if (retryBtn) retryBtn.style.display = 'none';
                dlg._hideTimer = setTimeout(function() {
                    window.hideReconnectingDialogue();
                }, 2500);
            } else if (state === 'offline') {
                dlg.classList.add('srd-offline');
                if (iconEl) iconEl.className = 'fas fa-wifi-slash srd-icon text-danger';
                if (retryBtn) retryBtn.style.display = 'inline-block';
            } else { // reconnecting / error
                if (iconEl) iconEl.className = 'fas fa-satellite-dish fa-spin srd-icon text-warning';
                if (retryBtn) retryBtn.style.display = 'inline-block';
            }

            dlg.style.display = 'block';
        };

        window.hideReconnectingDialogue = function() {
            var dlg = document.getElementById('stream-reconnecting-dialogue');
            if (dlg) {
                clearTimeout(dlg._hideTimer);
                dlg.style.display = 'none';
            }
        };

        window.forceReconnectLiveStream = function() {
            console.log('🔄 [SmartPlayer] User invoked manual Force Reconnect Live Stream.');
            if (typeof _reconnectTimer !== 'undefined') clearTimeout(_reconnectTimer);
            if (typeof _recoverySafetyTimer !== 'undefined') clearTimeout(_recoverySafetyTimer);
            _isRecovering = false;
            _lastRecoveryAttempt = 0;
            _reconnectAttempts = 0;
            window.userPaused = false;
            window.setAudioInterrupted(false);
            savePlayingIntent(true);
            window.showReconnectingDialogue("Connecting...", "Attempting immediate live stream connection...", "reconnecting");
            window.recoverLiveStream('user-force-retry');
        };

        window.setPlayerState = function(newState, message) {
            window._currentPlayerState = newState;
            var navbarPlayIcon = document.getElementById('navbar-play-icon');
            var miniPlayIcon   = document.getElementById('mini-play-icon');
            var playIcon       = document.getElementById('play-icon');
            var songInfo       = document.querySelector('.player-song');
            var playText       = document.getElementById('play-to-listen-text');
            var stickyPlayer   = document.getElementById('sticky-player');

            if (stickyPlayer) stickyPlayer.style.display = 'flex';

            if (newState === window.PLAYER_STATE.PLAYING) {
                if (navbarPlayIcon) navbarPlayIcon.className = "fas fa-pause me-1";
                if (miniPlayIcon)   miniPlayIcon.className   = "fas fa-pause";
                if (playIcon)       playIcon.className       = "fas fa-pause";

                if (songInfo) songInfo.style.display = 'block';
                if (playText) playText.style.display = 'none';

                if ('mediaSession' in navigator) {
                    navigator.mediaSession.playbackState = 'playing';
                }

                // If reconnecting dialogue was showing, flash green success then fade out
                var dlg = document.getElementById('stream-reconnecting-dialogue');
                if (dlg && dlg.style.display !== 'none' && !dlg.classList.contains('srd-success')) {
                    window.showReconnectingDialogue("Connected!", "Live stream resumed.", "success");
                }
                _reconnectAttempts = 0;
            } else if (newState === window.PLAYER_STATE.LOADING || newState === window.PLAYER_STATE.RECONNECTING) {
                if (navbarPlayIcon) navbarPlayIcon.className = "fas fa-spinner fa-spin me-1";
                if (miniPlayIcon)   miniPlayIcon.className   = "fas fa-spinner fa-spin";
                if (playIcon)       playIcon.className       = "fas fa-spinner fa-spin";

                if (songInfo) songInfo.style.display = 'none';
                if (playText) {
                    playText.textContent = message || (newState === window.PLAYER_STATE.RECONNECTING ? "Reconnecting stream..." : "Connecting to stream...");
                    playText.style.display = 'block';
                }

                if ('mediaSession' in navigator) {
                    try {
                        // CRITICAL FOR iOS BACKGROUND RECOVERY BEHIND GOOGLE MAPS:
                        // Never set playbackState = 'paused' while LOADING or RECONNECTING when user intent is active!
                        navigator.mediaSession.playbackState = (window.isIntentStillValid && window.isIntentStillValid() && !window.userPaused) ? 'playing' : 'paused';
                    } catch (e) {}
                }
            } else { // PAUSED, IDLE, ERROR
                if (navbarPlayIcon) navbarPlayIcon.className = "fas fa-play me-1";
                if (miniPlayIcon)   miniPlayIcon.className   = "fas fa-play";
                if (playIcon)       playIcon.className       = "fas fa-play";

                if (songInfo) songInfo.style.display = 'none';
                if (playText) {
                    playText.textContent = message || "Press Play To Listen";
                    playText.style.display = 'block';
                }

                if ('mediaSession' in navigator) {
                    try {
                        if (!window.userPaused && window.isIntentStillValid && window.isIntentStillValid()) {
                            navigator.mediaSession.playbackState = 'playing';
                        } else {
                            navigator.mediaSession.playbackState = 'paused';
                        }
                    } catch (e) {}
                }

                if (window.userPaused) {
                    window.hideReconnectingDialogue();
                }
            }
        };

        AudioPersistenceManager.prototype.updatePlayPauseIcons = function(isPlaying) {
            if (isPlaying && window.isRealAudioPlaying()) {
                window.setPlayerState(window.PLAYER_STATE.PLAYING);
            } else if (typeof _isRecovering !== 'undefined' && _isRecovering) {
                window.setPlayerState(window.PLAYER_STATE.RECONNECTING);
            } else {
                window.setPlayerState(window.PLAYER_STATE.PAUSED);
            }
        };

        var audioPersistenceManager = new AudioPersistenceManager();

        function togglePlayerDisplay(isPlaying) {
            if (isPlaying && window.isRealAudioPlaying()) {
                window.setPlayerState(window.PLAYER_STATE.PLAYING);
            } else if (typeof _isRecovering !== 'undefined' && _isRecovering) {
                window.setPlayerState(window.PLAYER_STATE.RECONNECTING);
            } else {
                window.setPlayerState(window.PLAYER_STATE.PAUSED);
            }
        }

        // Returns live stream URL with cache-buster timestamp and preserves existing parameters
        function getStreamUrl() {
            var audio = RadioAudio.get();
            if (!audio) return '';
            var base = (audio.getAttribute && audio.getAttribute('data-stream-url')) ||
                       (audio.querySelector && audio.querySelector('source') ? audio.querySelector('source').getAttribute('src') : '') ||
                       audio.src || '';
            if (!base) return '';
            if (window.location.protocol === 'https:' && base.indexOf('http:') === 0) {
                base = base.replace(/^http:/, 'https:');
            }
            // Strip any prior cache-buster parameter so query string remains clean
            base = base.replace(/([?&])_cb=\d+(&|$)/g, '$1').replace(/[?&]$/, '');
            var sep = base.indexOf('?') !== -1 ? '&' : '?';
            return base + sep + '_cb=' + Date.now();
        }

        var _lastMountAt = 0;
        var _lastSuccessfulPlayAt = 0;
        var _playInFlight = false;
        var _offlineBufferPurged = false;

        // Cleanly flush stale pre-disconnect audio frames when network drops so AirPlay never plays a split-second remnant on reconnect
        function purgeStaleAudioBufferOnOffline() {
            if (_offlineBufferPurged) return;
            var audio = RadioAudio.get();
            if (!audio) return;
            _offlineBufferPurged = true;
            try {
                clearTimeout(audio._waitingTimeout);
                clearTimeout(_reconnectTimer);
                if (audio._autoPlayOnReadyHandler) {
                    audio.removeEventListener('canplay', audio._autoPlayOnReadyHandler);
                    audio.removeEventListener('loadeddata', audio._autoPlayOnReadyHandler);
                    audio._autoPlayOnReadyHandler = null;
                }
                if (!audio.paused) {
                    audio.pause();
                }
            } catch (e) {}
        }

        // Atomic stream remount helper that preserves iOS Safari / Chrome MediaSession & gesture activation tokens
        function resetAndMountStream(audio, freshUrl) {
            if (!audio || !freshUrl) return;
            try {
                _lastMountAt = Date.now();
                _lastObservedStreamTime = -1;
                _offlineBufferPurged = false;
                _playInFlight = false;
                clearTimeout(audio._waitingTimeout);
                clearTimeout(_reconnectTimer);
                if (window.BgAudioBridge && !window.userPaused) {
                    window.BgAudioBridge.ensurePlaying();
                }
                try {
                    if (!audio.paused) {
                        audio.pause();
                    }
                } catch (e) {}
                while (audio.firstChild) {
                    audio.removeChild(audio.firstChild);
                }
                if (audio._autoPlayOnReadyHandler) {
                    audio.removeEventListener('canplay', audio._autoPlayOnReadyHandler);
                    audio.removeEventListener('loadeddata', audio._autoPlayOnReadyHandler);
                    audio._autoPlayOnReadyHandler = null;
                }
                audio._autoPlayOnReadyHandler = function() {
                    if (audio._autoPlayOnReadyHandler) {
                        audio.removeEventListener('canplay', audio._autoPlayOnReadyHandler);
                        audio.removeEventListener('loadeddata', audio._autoPlayOnReadyHandler);
                        audio._autoPlayOnReadyHandler = null;
                    }
                    clearTimeout(audio._waitingTimeout);
                    clearTimeout(_reconnectTimer);
                    clearTimeout(_recoverySafetyTimer);
                    _lastStreamTimeAdvanceAt = Date.now();
                    _lastSuccessfulPlayAt = Date.now();
                    _bgNetworkOffline = false;
                    if (!window.userPaused && window.isIntentStillValid && window.isIntentStillValid()) {
                        if (!audio.paused || _playInFlight) {
                            _isRecovering = false;
                            _reconnectAttempts = 0;
                            window.setPlayerState(window.PLAYER_STATE.PLAYING);
                            if (typeof window.startMetadataUpdates === 'function') window.startMetadataUpdates();
                            if (typeof window.reassertMediaSessionMetadata === 'function') window.reassertMediaSessionMetadata(true);
                            return;
                        }
                        _playInFlight = true;
                        var p = RadioAudio.play();
                        if (p && typeof p.then === 'function') {
                            p.then(function() {
                                _playInFlight = false;
                                clearTimeout(audio._waitingTimeout);
                                clearTimeout(_reconnectTimer);
                                clearTimeout(_recoverySafetyTimer);
                                _isRecovering = false;
                                _reconnectAttempts = 0;
                                _bgNetworkOffline = false;
                                _lastSuccessfulPlayAt = Date.now();
                                _lastStreamTimeAdvanceAt = Date.now();
                                window.setPlayerState(window.PLAYER_STATE.PLAYING);
                                if (typeof window.startMetadataUpdates === 'function') window.startMetadataUpdates();
                                if (typeof window.reassertMediaSessionMetadata === 'function') window.reassertMediaSessionMetadata(true);
                            }).catch(function() {
                                _playInFlight = false;
                            });
                        } else {
                            _playInFlight = false;
                        }
                    }
                };
                audio.addEventListener('canplay', audio._autoPlayOnReadyHandler);

                audio.src = freshUrl;
                audio.load();
            } catch(e) {}
        }


        function savePlayingIntent(shouldPlay) {
            try {
                window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent'), shouldPlay ? '1' : '0');
                if (shouldPlay) {
                    window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent_time'), Date.now().toString());
                }
                window.safeLocalStorage.setItem(window.getStationStorageKey('was_playing'), shouldPlay ? '1' : '0');
            } catch (e) {}
        }

        window.isIntentStillValid = function() {
            if (window.userPaused) return false;
            var intent = window.safeLocalStorage.getItem(window.getStationStorageKey('playing_intent'));
            if (intent !== '1') return false;
            var intentTimeStr = window.safeLocalStorage.getItem(window.getStationStorageKey('playing_intent_time'));
            var intentTime = intentTimeStr ? parseInt(intentTimeStr, 10) : 0;
            // Retain reconnection intent for at least 30 minutes during network loss / phone calls / car stops
            var THIRTY_MINUTES = 30 * 60 * 1000;
            if (Date.now() - intentTime > THIRTY_MINUTES) {
                return false;
            }
            return true;
        };

        window.audioInterruptedByDevice = false;
        window._lastAudioDisconnectTime = 0;
        window.setAudioInterrupted = function(val) {
            window.audioInterruptedByDevice = !!val;
            try {
                if (val) {
                    var nowStr = Date.now().toString();
                    window._lastAudioDisconnectTime = Date.now();
                    window.safeLocalStorage.setItem(window.getStationStorageKey('interrupted_by_device'), '1');
                    window.safeLocalStorage.setItem(window.getStationStorageKey('interrupted_time'), nowStr);
                    window.safeLocalStorage.setItem(window.getStationStorageKey('interrupted_disconnect_time'), nowStr);
                } else {
                    window.safeLocalStorage.removeItem(window.getStationStorageKey('interrupted_by_device'));
                    window.safeLocalStorage.removeItem(window.getStationStorageKey('interrupted_time'));
                }
            } catch(e) {}
        };

        window.getLastAudioDisconnectTime = function() {
            if (window._lastAudioDisconnectTime) return window._lastAudioDisconnectTime;
            try {
                var str = window.safeLocalStorage.getItem(window.getStationStorageKey('interrupted_disconnect_time'));
                return str ? parseInt(str, 10) : 0;
            } catch(e) {
                return 0;
            }
        };

        window.isAudioInterrupted = function() {
            if (window.audioInterruptedByDevice) return true;
            try {
                var isInt = window.safeLocalStorage.getItem(window.getStationStorageKey('interrupted_by_device')) === '1';
                if (!isInt) return false;
                var intTimeStr = window.safeLocalStorage.getItem(window.getStationStorageKey('interrupted_time'));
                var intTime = intTimeStr ? parseInt(intTimeStr, 10) : 0;
                // Auto-expire device interruption after 30 minutes
                if (Date.now() - intTime > (30 * 60 * 1000)) {
                    window.setAudioInterrupted(false);
                    return false;
                }
                return true;
            } catch(e) {
                return false;
            }
        };

        var _lastToggleTime = 0;
        window.userPaused = false;

        // WakeLock reference to prevent browser from freezing audio in background (ES5 compatible)
        var _wakeLock = null;
        function requestPlayerWakeLock() {
            if ('wakeLock' in navigator && navigator.wakeLock && typeof navigator.wakeLock.request === 'function') {
                try {
                    var p = navigator.wakeLock.request('screen');
                    if (p && typeof p.then === 'function') {
                        p.then(function(lock) {
                            _wakeLock = lock;
                            if (_wakeLock && _wakeLock.addEventListener) {
                                _wakeLock.addEventListener('release', function() { _wakeLock = null; });
                            }
                        }).catch(function() {});
                    }
                } catch(e) {}
            }
        }
        function releasePlayerWakeLock() {
            if (_wakeLock && _wakeLock.release) {
                try { _wakeLock.release(); } catch(e) {}
                _wakeLock = null;
            }
        }

        var _resumeOnGestureArmed = false;
        function armResumeOnFirstInteraction() {
            if (_resumeOnGestureArmed) return;
            _resumeOnGestureArmed = true;

            var gestureEvents = ['pointerdown', 'touchstart', 'touchend', 'click', 'keydown', 'scroll', 'wheel'];
            var onGesture = function(e) {
                _resumeOnGestureArmed = false;
                for (var i = 0; i < gestureEvents.length; i++) {
                    window.removeEventListener(gestureEvents[i], onGesture, true);
                    document.removeEventListener(gestureEvents[i], onGesture, true);
                }

                // If user specifically clicked a play/pause button, that button's click handler will execute
                if (e && e.target && e.target.closest && e.target.closest('#mini-play-btn, [data-action="toggle-play"], #navbar-play-btn, #hero-listen-btn, #play-btn')) {
                    return;
                }

                if (window.isIntentStillValid() && !window.userPaused && !window.isAudioInterrupted()) {
                    var audio = RadioAudio.get();
                    if (audio && (audio.src || (audio.querySelector && audio.querySelector('source')))) {
                        var p = RadioAudio.play();
                        if (p && typeof p.then === 'function') {
                            p.then(function() {
                                window.setPlayerState(window.PLAYER_STATE.PLAYING);
                                if (typeof window.reassertMediaSessionMetadata === 'function') {
                                    window.reassertMediaSessionMetadata(true);
                                }
                                requestPlayerWakeLock();
                            }).catch(function(err) {
                                window.recoverLiveStream('user-interaction-after-back');
                            });
                            return;
                        }
                    }
                    window.recoverLiveStream('user-interaction-after-back');
                }
            };

            for (var i = 0; i < gestureEvents.length; i++) {
                window.addEventListener(gestureEvents[i], onGesture, { capture: true, passive: true });
                document.addEventListener(gestureEvents[i], onGesture, { capture: true, passive: true });
            }
        }

        var _lastStreamTimeAdvanceAt = 0;
        var _lastObservedStreamTime = -1;
        var _bgNetworkOffline = false;
        var _isProbingNetwork = false;
        var _lastNetworkProbeAt = 0;

        function probeBackgroundNetwork(callback) {
            if (_isProbingNetwork) return;
            _isProbingNetwork = true;
            _lastNetworkProbeAt = Date.now();

            var probeDone = false;
            var timer = setTimeout(function() {
                if (probeDone) return;
                probeDone = true;
                _isProbingNetwork = false;
                if (callback) callback(false);
            }, 1800);

            var probeUrl = window.location.origin + '/favicon.ico?_bgprobe=' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);
            if (typeof window.fetch === 'function') {
                fetch(probeUrl, { method: 'HEAD', cache: 'no-store', credentials: 'omit' })
                    .then(function(res) {
                        if (probeDone) return;
                        probeDone = true;
                        clearTimeout(timer);
                        _isProbingNetwork = false;
                        if (callback) callback(true);
                    })
                    .catch(function() {
                        if (probeDone) return;
                        probeDone = true;
                        clearTimeout(timer);
                        _isProbingNetwork = false;
                        if (callback) callback(false);
                    });
            } else {
                clearTimeout(timer);
                _isProbingNetwork = false;
                var online = (typeof navigator.onLine === 'undefined') ? true : navigator.onLine;
                if (callback) callback(online);
            }
        }

        window.toggleLiveAudio = function toggleLiveAudio(forceState) {
            var now = Date.now();
            if (now - _lastToggleTime < 350) {
                return; // Debounce rapid multi-clicks
            }
            _lastToggleTime = now;

            var audio = RadioAudio.get();
            if (!audio) {
                console.error('Audio element not found');
                return;
            }

            var shouldPlay = (typeof forceState === 'boolean') ? forceState : (audio.paused || !window.isRealAudioPlaying());

            if (shouldPlay) {
                _resumeOnGestureArmed = false;
                window.userPaused = false;
                window.setAudioInterrupted(false);
                savePlayingIntent(true);
                _reconnectAttempts = 0;
                _bgNetworkOffline = false;
                _lastStreamTimeAdvanceAt = Date.now();
                try { window.safeLocalStorage.removeItem(window.getStationStorageKey('tab_closed_at')); } catch(e) {}

                // Start the continuous in-memory AVAudioSession keep-alive bridge synchronously on user gesture
                if (window.BgAudioBridge) {
                    window.BgAudioBridge.start();
                }

                window.setPlayerState(window.PLAYER_STATE.LOADING, "Connecting to stream...");

                // Completely purge existing buffer to ensure no stale seconds replay
                var freshUrl = getStreamUrl();
                resetAndMountStream(audio, freshUrl);

                _playInFlight = true;
                var playPromise = RadioAudio.play();
                if (playPromise && typeof playPromise.then === 'function') {
                    playPromise.then(function() {
                        _playInFlight = false;
                        _resumeOnGestureArmed = false;
                        _reconnectAttempts = 0;
                        _lastSuccessfulPlayAt = Date.now();
                        _lastStreamTimeAdvanceAt = Date.now();
                        window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent_time'), Date.now().toString());
                        audioPersistenceManager.saveAudioState();
                        window.setPlayerState(window.PLAYER_STATE.PLAYING);
                        window.showReconnectingDialogue("Connected!", "Live stream resumed.", "success");
                        if (typeof window.startMetadataUpdates === 'function') {
                            window.startMetadataUpdates();
                        }
                        if (typeof window.reassertMediaSessionMetadata === 'function') {
                            window.reassertMediaSessionMetadata(true);
                        }
                        requestPlayerWakeLock();
                    }).catch(function(error) {
                        _playInFlight = false;
                        console.error('Error playing audio:', error);
                        // In Safari, if play was aborted due to load() timing, canplay listener in resetAndMountStream handles it
                        if (error && (error.name === 'AbortError' || error.code === 20)) {
                            return;
                        }

                        if (error && (error.name === 'NotAllowedError' || error.name === 'SecurityError')) {
                            armResumeOnFirstInteraction();
                            if (!document.hidden) {
                                window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                            }
                            return;
                        }

                        var isOnline = (typeof navigator.onLine === 'undefined') ? true : navigator.onLine;
                        if (!isOnline) {
                            window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Waiting for network...");
                            window.showReconnectingDialogue("Network Offline", "Waiting for internet connection...", "offline");
                        } else if (window.isIntentStillValid()) {
                            window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Connecting to stream...");
                            window.showReconnectingDialogue("Connecting to Stream", "Establishing live audio connection...", "reconnecting");
                        } else {
                            window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                            window.hideReconnectingDialogue();
                        }
                    });
                } else {
                    _playInFlight = false;
                    window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent_time'), Date.now().toString());
                    audioPersistenceManager.saveAudioState();
                    window.setPlayerState(window.PLAYER_STATE.PLAYING);
                    requestPlayerWakeLock();
                }
            } else {
                window.userPaused = true;
                window.setAudioInterrupted(false);
                savePlayingIntent(false);
                clearTimeout(_reconnectTimer);
                clearTimeout(_recoverySafetyTimer);
                _isRecovering = false;
                _playInFlight = false;
                if (window.BgAudioBridge) {
                    window.BgAudioBridge.stop();
                }
                RadioAudio.pause();
                audioPersistenceManager.saveAudioState();
                window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                window.hideReconnectingDialogue();
                releasePlayerWakeLock();
            }
        };
        toggleLiveAudio = window.toggleLiveAudio;

        var _isRecovering = false;
        var _lastRecoveryAttempt = 0;
        var _reconnectAttempts = 0;
        var _reconnectTimer = null;
        var _recoverySafetyTimer = null;
        var _maxAutoReconnectAttempts = 999999;

        function getReconnectBackoff(attempt) {
            if (attempt <= 1) return 1200;
            if (attempt <= 4) return 2000;
            return 3000;
        }

        window.recoverLiveStream = function(reason) {
            var now = Date.now();
            var isManualOrMediaSession = (reason && (reason.indexOf('force') !== -1 || reason.indexOf('mediasession') !== -1 || reason.indexOf('user-interaction') !== -1));
            var isNetworkRestoredTrigger = (reason && (reason.indexOf('restored') !== -1 || reason.indexOf('online') !== -1));
            var liveCheck = RadioAudio.get();

            // Prevent double-remount / AirPlay split-second stop-start glitch:
            // Over Cellular + AirPlay, initial handshake and wireless AirPlay buffer stabilization takes up to ~8s.
            // Never allow a second watchdog/stalled/online event to tear down a stream that just mounted or just started playing!
            if (!isManualOrMediaSession && liveCheck) {
                var isActivelyPlaying = !liveCheck.paused && !liveCheck.ended && !liveCheck.error && (liveCheck.readyState >= 2 || now - _lastSuccessfulPlayAt < 9000 || now - _lastStreamTimeAdvanceAt < 6500);
                if (isActivelyPlaying) {
                    _isRecovering = false;
                    _bgNetworkOffline = false;
                    clearTimeout(_reconnectTimer);
                    if (liveCheck._waitingTimeout) clearTimeout(liveCheck._waitingTimeout);
                    return;
                }
                var mountGuardWindow = isNetworkRestoredTrigger ? 6000 : 9000;
                if ((now - _lastMountAt < mountGuardWindow) || (_isRecovering && (now - _lastRecoveryAttempt < 6000)) || _playInFlight) {
                    return;
                }
            }

            if (!window.isIntentStillValid() || window.userPaused) {
                window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                window.hideReconnectingDialogue();
                _isRecovering = false;
                return;
            }

            // Ensure background keep-alive bridge remains playing so iOS never suspends this tab behind Google Maps
            if (window.BgAudioBridge) {
                window.BgAudioBridge.ensurePlaying();
            }

            var isOnline = (typeof navigator.onLine === 'undefined') ? true : navigator.onLine;
            if ((!isOnline || _bgNetworkOffline) && !isManualOrMediaSession && !isNetworkRestoredTrigger) {
                // While network is confirmed offline, flush stale pre-disconnect audio buffer once and wait for online/probe restore
                // instead of hammering audio.load() while offline (which causes queued AirPlay glitches on reconnect).
                purgeStaleAudioBufferOnOffline();
                window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Waiting for network...");
                window.showReconnectingDialogue("Network Offline", "Waiting for internet connection...", "offline");
                _isRecovering = false;
                return;
            }

            if (window.isAudioInterrupted()) {
                var timeSinceDisc = now - window.getLastAudioDisconnectTime();
                var isImmediateRestore = (reason && (reason.indexOf('restored') !== -1 || reason.indexOf('force') !== -1 || reason.indexOf('reconnect') !== -1 || reason.indexOf('mediasession') !== -1));
                // Allow recovery after 2.5s stabilization window or explicit reconnect/background restoration
                if (!isImmediateRestore && timeSinceDisc < 2500) {
                    _isRecovering = false;
                    return;
                }
                window.setAudioInterrupted(false);
            }

            clearTimeout(_reconnectTimer);
            _isRecovering = true;
            _lastRecoveryAttempt = now;
            _reconnectAttempts++;

            // Refresh playing_intent_time during active recovery so long drives in dead zones never expire intent prematurely
            try {
                window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent_time'), now.toString());
            } catch (e) {}

            // Safety watchdog timer: guarantees _isRecovering resets even if stream socket hangs
            clearTimeout(_recoverySafetyTimer);
            _recoverySafetyTimer = setTimeout(function() {
                _isRecovering = false;
                _playInFlight = false;
            }, 6500);

            window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Reconnecting stream...");
            var attemptLabel = _reconnectAttempts > 1 ? " (Attempt " + _reconnectAttempts + ")" : "";
            window.showReconnectingDialogue("Stream Connection Lost", "Reconnecting to live stream" + attemptLabel + "...", "reconnecting");

            var audio = RadioAudio.get();
            if (!audio) {
                _isRecovering = false;
                return;
            }

            // Flush old buffer completely and mount fresh timestamped stream URL
            var freshUrl = getStreamUrl();
            resetAndMountStream(audio, freshUrl);

            _playInFlight = true;
            var p = RadioAudio.play();
            if (p && typeof p.then === 'function') {
                p.then(function() {
                    _playInFlight = false;
                    _isRecovering = false;
                    _reconnectAttempts = 0;
                    _bgNetworkOffline = false;
                    _lastSuccessfulPlayAt = Date.now();
                    _lastStreamTimeAdvanceAt = Date.now();
                    clearTimeout(audio._waitingTimeout);
                    clearTimeout(_reconnectTimer);
                    clearTimeout(_recoverySafetyTimer);
                    _resumeOnGestureArmed = false;
                    window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent_time'), Date.now().toString());
                    audioPersistenceManager.saveAudioState();
                    window.setPlayerState(window.PLAYER_STATE.PLAYING);
                    window.showReconnectingDialogue("Connected!", "Live stream resumed.", "success");
                    if (typeof window.startMetadataUpdates === 'function') {
                        window.startMetadataUpdates();
                    }
                    if (typeof window.reassertMediaSessionMetadata === 'function') {
                        window.reassertMediaSessionMetadata(true);
                    }
                    requestPlayerWakeLock();
                }).catch(function(err) {
                    _playInFlight = false;
                    // In Safari / AirPlay, play() invoked synchronously after load() often rejects with AbortError while canplay is still buffering
                    if (err && (err.name === 'AbortError' || err.code === 20)) {
                        return;
                    }
                    console.warn('⚠️ [LiveStreamWatchdog] Reconnect attempt rejected/failed (' + reason + '):', err);
                    _isRecovering = false;

                    // Keep background audio bridge alive and NEVER stop background retry loop!
                    if (window.BgAudioBridge && !window.userPaused) {
                        window.BgAudioBridge.ensurePlaying();
                    }

                    if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) {
                        armResumeOnFirstInteraction();
                    }

                    if (window.isIntentStillValid() && !window.userPaused) {
                        clearTimeout(_reconnectTimer);
                        var delay = getReconnectBackoff(_reconnectAttempts);
                        var onlineStatus = ((typeof navigator.onLine === 'undefined') ? true : navigator.onLine) && !_bgNetworkOffline;
                        if (!onlineStatus) {
                            purgeStaleAudioBufferOnOffline();
                            window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Waiting for network...");
                            window.showReconnectingDialogue("Network Offline", "Waiting for internet connection...", "offline");
                        } else {
                            window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Reconnecting stream...");
                            window.showReconnectingDialogue("Stream Connection Lost", "Reconnecting in " + Math.max(1, Math.round(delay / 1000)) + "s...", "reconnecting");
                            _reconnectTimer = setTimeout(function() {
                                if (window.isIntentStillValid() && !window.userPaused) {
                                    window.recoverLiveStream('scheduled-retry-' + _reconnectAttempts);
                                }
                            }, delay);
                        }
                    } else {
                        window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                        window.hideReconnectingDialogue();
                    }
                });
            } else {
                _playInFlight = false;
                _isRecovering = false;
                _reconnectAttempts = 0;
                _lastSuccessfulPlayAt = Date.now();
                _lastStreamTimeAdvanceAt = Date.now();
                clearTimeout(_reconnectTimer);
                clearTimeout(_recoverySafetyTimer);
                window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent_time'), Date.now().toString());
                window.setPlayerState(window.PLAYER_STATE.PLAYING);
                window.showReconnectingDialogue("Connected!", "Live stream resumed.", "success");
            }
        };

        window.verifyStreamHealthOnForeground = function(source) {
            if (!window.isIntentStillValid() || window.userPaused) {
                return;
            }

            if (window.BgAudioBridge) {
                window.BgAudioBridge.ensurePlaying();
            }

            var audio = RadioAudio.get();
            if (!audio) return;

            var now = Date.now();
            if ((now - _lastMountAt < 8000) || (now - _lastSuccessfulPlayAt < 8000) || _isRecovering || _playInFlight) {
                return;
            }

            if (audio.paused || audio.error || audio.networkState === 3 || audio.readyState < 2) {
                console.warn('⚠️ [StreamHealth] Audio not playing upon returning (' + source + ') — recovering fresh live stream...');
                window.setAudioInterrupted(false);
                window.recoverLiveStream('foreground-' + source);
                return;
            }

            var sampleTime = audio.currentTime;
            setTimeout(function() {
                if (window.isIntentStillValid() && !window.userPaused) {
                    var currentAudio = RadioAudio.get();
                    var nowCheck = Date.now();
                    if ((nowCheck - _lastMountAt < 8000) || (nowCheck - _lastSuccessfulPlayAt < 8000) || _isRecovering || _playInFlight) {
                        return;
                    }
                    if (currentAudio) {
                        if (currentAudio.paused || currentAudio.readyState < 2 || currentAudio.currentTime === sampleTime) {
                            console.warn('⚠️ [StreamHealth] Audio frozen/silent upon returning (' + source + ') — auto-recovering...');
                            window.recoverLiveStream('foreground-frozen-time');
                        } else {
                            window.setPlayerState(window.PLAYER_STATE.PLAYING);
                        }
                    }
                }
            }, 900);
        };

        function attemptAutoResumeOnBack(reason) {
            RadioAudio.reset();
            var audio = RadioAudio.get();
            if (!audio) return;

            setupAudioListeners();

            if (window.userPaused || !window.isIntentStillValid()) {
                window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                return;
            }

            if (window.BgAudioBridge) {
                window.BgAudioBridge.ensurePlaying();
            }

            if (window.isRealAudioPlaying && window.isRealAudioPlaying()) {
                _resumeOnGestureArmed = false;
                window.setPlayerState(window.PLAYER_STATE.PLAYING);
                if (typeof window.reassertMediaSessionMetadata === 'function') {
                    window.reassertMediaSessionMetadata(true);
                }
                return;
            }

            var hasSource = (audio.src && audio.src.indexOf('http') !== -1) || (audio.querySelector && audio.querySelector('source'));
            if (!hasSource) {
                var freshUrl = getStreamUrl();
                resetAndMountStream(audio, freshUrl);
            }

            window.setPlayerState(window.PLAYER_STATE.PLAYING);

            var p = RadioAudio.play();
            if (p && typeof p.then === 'function') {
                p.then(function() {
                    _resumeOnGestureArmed = false;
                    _lastSuccessfulPlayAt = Date.now();
                    _lastStreamTimeAdvanceAt = Date.now();
                    window.setPlayerState(window.PLAYER_STATE.PLAYING);
                    if (typeof window.reassertMediaSessionMetadata === 'function') {
                        window.reassertMediaSessionMetadata(true);
                    }
                    requestPlayerWakeLock();
                }).catch(function(err) {
                    console.warn('⚠️ Audio play on navigation rejected (' + reason + '):', err);
                    if (err && (err.name === 'NotAllowedError' || err.name === 'SecurityError')) {
                        window.setPlayerState(window.PLAYER_STATE.PLAYING);
                        armResumeOnFirstInteraction();
                    } else {
                        window.recoverLiveStream('auto-resume-' + reason);
                    }
                });
                return;
            } else {
                window.setPlayerState(window.PLAYER_STATE.PLAYING);
            }
        }

        function initAudio() {
            var liveAudio = RadioAudio.get();
            if (!liveAudio) return null;

            if ('mediaSession' in navigator) {
                try {
                    navigator.mediaSession.setActionHandler('play', function() {
                        window.userPaused = false;
                        window.setAudioInterrupted(false);
                        savePlayingIntent(true);
                        if (window.BgAudioBridge) window.BgAudioBridge.start();
                        window.recoverLiveStream('mediasession-play');
                    });
                } catch (e) {}

                try {
                    navigator.mediaSession.setActionHandler('pause', function() {
                        var timeSinceDisconnect = Date.now() - window.getLastAudioDisconnectTime();
                        // Only treat mediaSession pause as involuntary if within 2500ms of an actual hardware route disconnect or while network is offline.
                        // Do NOT block explicit Lock-Screen / CarPlay user Pause taps during recovery or after interruption state is set.
                        var isSystemOrNetworkPause = (timeSinceDisconnect < 2500) || _bgNetworkOffline || (typeof navigator.onLine !== 'undefined' && !navigator.onLine);

                        if (isSystemOrNetworkPause) {
                            window.userPaused = false;
                            window.setAudioInterrupted(true);
                            RadioAudio.pause();
                            if (window.BgAudioBridge) window.BgAudioBridge.ensurePlaying();
                        } else {
                            window.userPaused = true;
                            window.setAudioInterrupted(false);
                            savePlayingIntent(false);
                            if (window.BgAudioBridge) window.BgAudioBridge.stop();
                            RadioAudio.pause();
                            window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                            releasePlayerWakeLock();
                        }
                    });
                } catch (e) {}

                try {
                    navigator.mediaSession.setActionHandler('stop', function() {
                        window.userPaused = true;
                        window.setAudioInterrupted(false);
                        savePlayingIntent(false);
                        if (window.BgAudioBridge) window.BgAudioBridge.stop();
                        RadioAudio.pause();
                        window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                        releasePlayerWakeLock();
                    });
                } catch (e) {}
            }

            return liveAudio;
        }

        function setupAudioListeners() {
            var liveAudio = RadioAudio.get();
            if (!liveAudio) return;

            if (liveAudio._hasBoundListeners) return;
            liveAudio._hasBoundListeners = true;

            liveAudio.addEventListener('timeupdate', function() {
                if (typeof liveAudio.currentTime === 'number' && liveAudio.currentTime !== _lastObservedStreamTime) {
                    _lastObservedStreamTime = liveAudio.currentTime;
                    _lastStreamTimeAdvanceAt = Date.now();
                    _bgNetworkOffline = false;
                    _offlineBufferPurged = false;
                    clearTimeout(_reconnectTimer);
                    if (liveAudio._waitingTimeout) clearTimeout(liveAudio._waitingTimeout);
                }
            });

            liveAudio.addEventListener('playing', function() {
                _playInFlight = false;
                _isRecovering = false;
                _reconnectAttempts = 0;
                _bgNetworkOffline = false;
                _offlineBufferPurged = false;
                _lastSuccessfulPlayAt = Date.now();
                _lastStreamTimeAdvanceAt = Date.now();
                clearTimeout(_reconnectTimer);
                clearTimeout(_recoverySafetyTimer);
                if (liveAudio._waitingTimeout) clearTimeout(liveAudio._waitingTimeout);
                window.safeLocalStorage.setItem(window.getStationStorageKey('playing_intent_time'), Date.now().toString());
                audioPersistenceManager.saveAudioState();
                window.setPlayerState(window.PLAYER_STATE.PLAYING);
                if (window.BgAudioBridge && !window.userPaused) {
                    window.BgAudioBridge.ensurePlaying();
                }
                if (typeof window.startMetadataUpdates === 'function') {
                    window.startMetadataUpdates();
                }
                if (typeof window.reassertMediaSessionMetadata === 'function') {
                    window.reassertMediaSessionMetadata(true);
                }
            });

            liveAudio.addEventListener('pause', function() {
                audioPersistenceManager.saveAudioState();
                releasePlayerWakeLock();

                // 1. Explicit user pause
                if (window.userPaused) {
                    window.setAudioInterrupted(false);
                    if (window.BgAudioBridge) window.BgAudioBridge.stop();
                    window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                    window.hideReconnectingDialogue();
                    return;
                }

                // 2. Involuntary pause while intent is active (cellular drop, Bluetooth/CarPlay transition, or Google Maps navigation prompt)
                if (window.isIntentStillValid()) {
                    if (window.BgAudioBridge) {
                        window.BgAudioBridge.ensurePlaying();
                    }

                    // Ignore synthetic pause fired by audio.load(), offline buffer purge, or during AirPlay stabilization window
                    var nowPause = Date.now();
                    if (_isRecovering || _playInFlight || _offlineBufferPurged || (nowPause - _lastMountAt < 6000) || (nowPause - _lastSuccessfulPlayAt < 5000)) {
                        return;
                    }

                    if (window.isAudioInterrupted()) {
                        // Paused briefly for Bluetooth/CarPlay disconnect; background watchdog will auto-recover once route stabilizes
                        return;
                    }

                    var isOnline = ((typeof navigator.onLine === 'undefined') ? true : navigator.onLine) && !_bgNetworkOffline;
                    if (!isOnline) {
                        purgeStaleAudioBufferOnOffline();
                        window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Waiting for network...");
                        window.showReconnectingDialogue("Network Offline", "Waiting for internet connection...", "offline");
                    } else {
                        window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Reconnecting stream...");
                        window.recoverLiveStream('involuntary-pause');
                    }
                } else {
                    window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                    window.hideReconnectingDialogue();
                }
            });

            liveAudio.addEventListener('volumechange', function() {
                audioPersistenceManager.saveAudioState();
            });

            liveAudio.addEventListener('stalled', function() {
                if (window.isIntentStillValid() && !window.userPaused) {
                    var nowStall = Date.now();
                    // On iOS Safari + AirPlay, WebKit routinely fires 'stalled' while filling the AirPlay jitter buffer right after mounting.
                    // Never remount on 'stalled' unless the stream has been mounted > 9s and genuinely stopped advancing for > 6.5s!
                    if (_isRecovering || _playInFlight || (nowStall - _lastMountAt < 9000) || (nowStall - _lastSuccessfulPlayAt < 8000) || (nowStall - _lastStreamTimeAdvanceAt < 6500)) {
                        return;
                    }
                    console.warn('⚠️ [SmartPlayer] Stream stalled event confirmed after stabilization window.');
                    window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Reconnecting stream...");
                    window.recoverLiveStream('stalled');
                }
            });

            liveAudio.addEventListener('error', function() {
                console.error('⚠️ [SmartPlayer] Live audio error:', liveAudio.error);
                if (window.isIntentStillValid() && !window.userPaused) {
                    var isOnline = ((typeof navigator.onLine === 'undefined') ? true : navigator.onLine) && !_bgNetworkOffline;
                    if (!isOnline) {
                        purgeStaleAudioBufferOnOffline();
                        window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Waiting for network...");
                        window.showReconnectingDialogue("Network Offline", "Waiting for internet connection...", "offline");
                    } else {
                        window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Reconnecting stream...");
                        window.recoverLiveStream('error');
                    }
                }
            });

            liveAudio.addEventListener('ended', function() {
                console.warn('⚠️ [SmartPlayer] Stream ended unexpectedly.');
                if (window.isIntentStillValid() && !window.userPaused) {
                    window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Reconnecting stream...");
                    window.recoverLiveStream('ended');
                }
            });

            liveAudio.addEventListener('waiting', function() {
                clearTimeout(liveAudio._waitingTimeout);
                liveAudio._waitingTimeout = setTimeout(function() {
                    var now = Date.now();
                    var stalledTooLong = (now - _lastStreamTimeAdvanceAt > 6500) && (now - _lastSuccessfulPlayAt > 8000) && (now - _lastMountAt > 9000);
                    if (window.isIntentStillValid() && !window.userPaused && !_isRecovering && !_playInFlight && stalledTooLong) {
                        console.warn('⚠️ [SmartPlayer] Audio waiting timeout (buffer exhausted).');
                        window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Buffering...");
                        window.showReconnectingDialogue("Buffering Stream", "Recovering audio connection...", "reconnecting");
                        window.recoverLiveStream('waiting-timeout');
                    }
                }, 6500);
            });
        }

        // Immediate network connection recovery listeners
        window.addEventListener('online', function() {
            _bgNetworkOffline = false;
            if (window.isIntentStillValid() && !window.userPaused) {
                console.log('🌐 [SmartPlayer] Network online event fired — resuming stream immediately.');
                window.showReconnectingDialogue("Internet Restored", "Reconnecting to live stream...", "reconnecting");
                window.recoverLiveStream('network-online-restored');
            }
        });

        window.addEventListener('offline', function() {
            _bgNetworkOffline = true;
            if (window.isIntentStillValid() && !window.userPaused) {
                console.log('🌐 [SmartPlayer] Network offline event fired — flushing stale buffer and waiting for network.');
                if (window.BgAudioBridge) window.BgAudioBridge.ensurePlaying();
                purgeStaleAudioBufferOnOffline();
                window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Offline. Waiting for network...");
                window.showReconnectingDialogue("Network Offline", "Waiting for internet connection...", "offline");
            }
        });

        if (typeof navigator !== 'undefined' && navigator.connection && typeof navigator.connection.addEventListener === 'function') {
            navigator.connection.addEventListener('change', function() {
                if (window.isIntentStillValid() && !window.userPaused) {
                    probeBackgroundNetwork(function(isReachable) {
                        if (isReachable) {
                            var wasOffline = _bgNetworkOffline;
                            _bgNetworkOffline = false;
                            var a = RadioAudio.get();
                            var nowConn = Date.now();
                            var recentlyStartedOrMounting = _isRecovering || _playInFlight || (nowConn - _lastMountAt < 9000) || (nowConn - _lastSuccessfulPlayAt < 8000);
                            if (!recentlyStartedOrMounting && (wasOffline || !a || a.paused || a.error || (nowConn - _lastStreamTimeAdvanceAt > 6500))) {
                                window.recoverLiveStream('network-connection-change-restored');
                            }
                        } else {
                            _bgNetworkOffline = true;
                            purgeStaleAudioBufferOnOffline();
                        }
                    });
                }
            });
        }

        // Intelligent route change & device tracking for iOS Safari / CarPlay / Bluetooth / Android Auto
        var _lastKnownAudioDeviceCount = null;
        var _isCheckingRouteChange = false;
        var _resumeDebounceTimer = null;

        function handleAudioRouteChange(source) {
            if (_isCheckingRouteChange) return;
            _isCheckingRouteChange = true;

            var enumerate = (typeof navigator !== 'undefined' && navigator.mediaDevices && typeof navigator.mediaDevices.enumerateDevices === 'function')
                ? navigator.mediaDevices.enumerateDevices()
                : (typeof Promise !== 'undefined' ? Promise.resolve([]) : null);

            if (!enumerate) {
                _isCheckingRouteChange = false;
                return;
            }

            enumerate.then(function(devices) {
                _isCheckingRouteChange = false;
                var currentCount = 0;
                for (var i = 0; i < devices.length; i++) {
                    if (devices[i].kind === 'audioinput' || devices[i].kind === 'audiooutput') {
                        currentCount++;
                    }
                }

                var prevCount = _lastKnownAudioDeviceCount;
                _lastKnownAudioDeviceCount = currentCount;
                var now = Date.now();

                if (prevCount === null) {
                    return; // Baseline established
                }

                // 1. DISCONNECT DETECTION: ONLY when hardware device count genuinely decreased!
                // Never treat a generic 'devicechange' while playing (e.g. Google Maps voice guidance or Bluetooth connecting) as a disconnect!
                var isDisconnect = (currentCount < prevCount);

                if (isDisconnect) {
                    clearTimeout(_resumeDebounceTimer);
                    window.userPaused = false;
                    window.setAudioInterrupted(true);
                    RadioAudio.pause();
                    if (window.BgAudioBridge) window.BgAudioBridge.ensurePlaying();
                    window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                    releasePlayerWakeLock();
                    return;
                }

                // 2. RECONNECT DETECTION (Bluetooth / CarPlay / Android Auto):
                // Require an actual hardware device addition (currentCount > prevCount) or explicit devicechange event after stabilization
                // so turning off the car / disconnecting headphones never auto-blasts through the iPhone speaker 2.5s later.
                var timeSinceDisconnect = now - window.getLastAudioDisconnectTime();
                var isReconnect = (currentCount > prevCount) || (source === 'devicechange' && window.isAudioInterrupted() && timeSinceDisconnect > 1200);

                if (isReconnect && window.isIntentStillValid() && !window.userPaused) {
                    var live = RadioAudio.get();
                    var recentlyMounting = _isRecovering || _playInFlight || (now - _lastMountAt < 8000) || (now - _lastSuccessfulPlayAt < 7000);
                    var needsResume = !recentlyMounting && (window.isAudioInterrupted() || !live || live.paused || live.error || live.readyState < 2 || (now - _lastStreamTimeAdvanceAt > 6500));
                    if (needsResume) {
                        clearTimeout(_resumeDebounceTimer);
                        _resumeDebounceTimer = setTimeout(function() {
                            if (window.isIntentStillValid() && !window.userPaused) {
                                window.setAudioInterrupted(false);
                                savePlayingIntent(true);
                                _isRecovering = false;
                                _reconnectAttempts = 0;
                                window.recoverLiveStream('carplay-bt-reconnected-' + source);
                            }
                        }, 600);
                    }
                }
            }).catch(function(err) {
                _isCheckingRouteChange = false;
            });
        }

        if (typeof navigator !== 'undefined' && navigator.mediaDevices) {
            handleAudioRouteChange('init');
            if (typeof navigator.mediaDevices.addEventListener === 'function') {
                navigator.mediaDevices.addEventListener('devicechange', function() {
                    handleAudioRouteChange('devicechange');
                });
            }
        }

        function runPeriodicWatchdog(source) {
            if (window.userPaused || !window.isIntentStillValid()) {
                if (window._currentPlayerState === window.PLAYER_STATE.PLAYING && !window.isRealAudioPlaying()) {
                    window.setPlayerState(window.PLAYER_STATE.PAUSED, "Press Play To Listen");
                }
                return;
            }

            // Keep the in-memory AVAudioSession bridge playing so iOS never suspends the tab behind Google Maps
            if (window.BgAudioBridge) {
                window.BgAudioBridge.ensurePlaying();
            }

            var now = Date.now();

            // Check Bluetooth / CarPlay route recovery in background
            // Delegate strictly to handleAudioRouteChange('watchdog') so playback only resumes when enumerateDevices()
            // confirms an audio output device reconnected (preventing unwanted speaker playback after CarPlay/BT disconnect).
            if (window.isAudioInterrupted()) {
                handleAudioRouteChange('watchdog');
                return;
            }

            var audio = RadioAudio.get();
            if (!audio) return;

            // Never interrupt a stream that is actively mounting or within its 9s post-mount / 8s post-play AirPlay stabilization window
            var inStabilizationWindow = _isRecovering || _playInFlight || (now - _lastMountAt < 9000) || (now - _lastSuccessfulPlayAt < 8000);
            var timeSinceAdvance = (_lastStreamTimeAdvanceAt > 0) ? (now - _lastStreamTimeAdvanceAt) : 0;
            var isStreamFrozen = (!inStabilizationWindow && !audio.paused && timeSinceAdvance >= 7500);
            var isStreamDown = (!inStabilizationWindow && (audio.paused || audio.ended || !!audio.error || audio.readyState < 2 || isStreamFrozen));

            // Probe actual network reachability in the background (crucial on iOS when Cellular is toggled in Control Center behind Google Maps)
            if (isStreamDown || _bgNetworkOffline || (document.hidden && (now - _lastNetworkProbeAt >= 2500))) {
                probeBackgroundNetwork(function(isReachable) {
                    if (!isReachable) {
                        _bgNetworkOffline = true;
                        purgeStaleAudioBufferOnOffline();
                        window.setPlayerState(window.PLAYER_STATE.RECONNECTING, "Waiting for network...");
                        window.showReconnectingDialogue("Network Offline", "Waiting for internet connection...", "offline");
                    } else {
                        var wasOffline = _bgNetworkOffline;
                        _bgNetworkOffline = false;
                        var currentAudio = RadioAudio.get();
                        var nowProbe = Date.now();
                        var recentlyStartedOrMounting = _isRecovering || _playInFlight || (nowProbe - _lastMountAt < 9000) || (nowProbe - _lastSuccessfulPlayAt < 8000);
                        var stillDown = !recentlyStartedOrMounting && (!currentAudio || currentAudio.paused || currentAudio.ended || !!currentAudio.error || ((nowProbe - _lastStreamTimeAdvanceAt) >= 7500));
                        if (wasOffline) {
                            // Cellular just came back online! Trigger a single clean recovery if not already mounting within the last 6s
                            if (!_isRecovering && !_playInFlight && (nowProbe - _lastMountAt >= 6000)) {
                                window.recoverLiveStream('bg-cellular-restored-' + source);
                            }
                        } else if (stillDown) {
                            window.recoverLiveStream('watchdog-' + source);
                        }
                    }
                });
            }
        }
        window._runBgWatchdogTick = runPeriodicWatchdog;

        // Periodic background interval (runs every 1.5s)
        setInterval(function() {
            runPeriodicWatchdog('interval');
        }, 1500);

        // Web Worker heartbeat: keeps background tabs actively checking every 1.5s without throttling
        // Together with BgAudioBridge's CoreAudio timeupdate clock, guarantees instant background refresh in Google Maps
        try {
            if (typeof window.Worker !== 'undefined' && typeof window.Blob !== 'undefined') {
                var workerBlob = new Blob([
                    'var timer = setInterval(function() { postMessage("tick"); }, 1500);'
                ], { type: 'application/javascript' });
                var workerUrl = URL.createObjectURL(workerBlob);
                var bgWorker = new Worker(workerUrl);
                bgWorker.onmessage = function() {
                    runPeriodicWatchdog('worker-heartbeat');
                };
            }
        } catch (e) {}

        // Global delegated click handler for all play/pause buttons
        document.addEventListener('click', function(e) {
            var btn = e.target && e.target.closest ? e.target.closest('#mini-play-btn, [data-action="toggle-play"], #navbar-play-btn, #hero-listen-btn') : null;
            if (btn) {
                // If button has an inline onclick handler (e.g. #mini-play-btn), let the inline onclick execute directly
                if (btn.id === 'mini-play-btn' && btn.getAttribute('onclick')) {
                    return;
                }
                e.preventDefault();
                e.stopPropagation();
                window.toggleLiveAudio();
            }
        });

        // Safari BFCache & page restoration lifecycle handlers
        window.addEventListener('pageshow', function(e) {
            if (audioPersistenceManager) {
                audioPersistenceManager.isActiveTab = true;
                try {
                    window.safeLocalStorage.setItem(audioPersistenceManager.storageKey + '_current_tab', audioPersistenceManager.tabId);
                } catch(err) {}
            }
            attemptAutoResumeOnBack('pageshow' + (e.persisted ? '-bfcache' : ''));
        });

        window.addEventListener('pagehide', function() {
            audioPersistenceManager.saveAudioState();
        });

        window.addEventListener('popstate', function() {
            if (audioPersistenceManager) {
                audioPersistenceManager.isActiveTab = true;
            }
            attemptAutoResumeOnBack('popstate');
        });

        document.addEventListener('htmx:historyRestore', function() {
            attemptAutoResumeOnBack('htmx-historyRestore');
        });

        document.addEventListener('DOMContentLoaded', function() {
            initAudio();
            setupAudioListeners();

            var miniPlayBtn = document.getElementById('mini-play-btn');
            if (miniPlayBtn) {
                miniPlayBtn.addEventListener('click', function(e) {
                    e.preventDefault();
                    e.stopPropagation();
                    window.toggleLiveAudio();
                });
            }

            var playerInfo = document.querySelector('.player-info');
            if (playerInfo) {
                playerInfo.addEventListener('click', function(e) {
                    if (e.target && e.target.closest && (e.target.closest('#mini-play-btn') || e.target.closest('a') || e.target.closest('button'))) return;
                    window.toggleLiveAudio();
                });
            }

            var stickyPlayer = document.getElementById('sticky-player');
            if (stickyPlayer) {
                stickyPlayer.style.display = 'flex';
            }
        });
    </script>
