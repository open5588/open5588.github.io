param location string = resourceGroup().location
param environmentName string = 'cae-grocery-scrapers-prod'
param storageAccountName string = 'stgroceryscrapers${uniqueString(resourceGroup().id)}'
param acrName string = 'acrgroceryscrapers${uniqueString(resourceGroup().id)}'

resource storageAccount 'Microsoft.Storage/storageAccounts@2023-01-01' = {
  name: storageAccountName
  location: location
  sku: {
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
}

resource blobServices 'Microsoft.Storage/storageAccounts/blobServices@2023-01-01' = {
  parent: storageAccount
  name: 'default'
}

resource datasetContainer 'Microsoft.Storage/storageAccounts/blobServices/containers@2023-01-01' = {
  parent: blobServices
  name: 'grocery-scraper-datasets'
}

resource containerAppEnv 'Microsoft.App/managedEnvironments@2023-05-01' = {
  name: environmentName
  location: location
  properties: {}
}

resource walmartScraperJob 'Microsoft.App/jobs@2023-05-01' = {
  name: 'job-walmart-scraper'
  location: location
  properties: {
    environmentId: containerAppEnv.id
    configuration: {
      triggerType: 'Schedule'
      replicaTimeout: 5400
      replicaRetryLimit: 2
      scheduleTriggerConfig: {
        cronExpression: '0 6 * * 1' // Weekly Monday 06:00 UTC
        parallelism: 1
        replicaCompletionCount: 1
      }
    }
    template: {
      containers: [
        {
          name: 'walmart-scraper'
          image: '${acrName}.azurecr.io/grocery-scraper:latest'
          command: ['python3', 'walmart_azure_scraper.py', '--zip', '60085', '--store-id', '1497']
          resources: {
            cpu: json('1.0')
            memory: '2Gi'
          }
        }
      ]
    }
  }
}

resource marianosScraperJob 'Microsoft.App/jobs@2023-05-01' = {
  name: 'job-marianos-scraper'
  location: location
  properties: {
    environmentId: containerAppEnv.id
    configuration: {
      triggerType: 'Schedule'
      replicaTimeout: 5400
      replicaRetryLimit: 2
      scheduleTriggerConfig: {
        cronExpression: '0 7 * * 1' // Weekly Monday 07:00 UTC
        parallelism: 1
        replicaCompletionCount: 1
      }
    }
    template: {
      containers: [
        {
          name: 'marianos-scraper'
          image: '${acrName}.azurecr.io/grocery-scraper:latest'
          command: ['python3', 'marianos_azure_scraper.py']
          resources: {
            cpu: json('1.0')
            memory: '2Gi'
          }
        }
      ]
    }
  }
}
