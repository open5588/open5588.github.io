#!/usr/bin/env python3
"""
Robust Mariano's Scraper for Microsoft Azure Environment (Contest #2796392)
===========================================================================
Target Architecture: Azure Container Apps Jobs / Azure Functions (Docker)
Engine: Python 3.11 + Playwright (Async Chromium) + Kroger/Mariano's Modality Lock

Key Capabilities:
1. Store & Fulfillment Context Locking: Locks Mariano's facility ID (e.g., `53400029`
   Gurnee/Waukegan IL `60031` or Chicago `60601`) and `PICKUP` / `IN_STORE` modality
   headers (`x-laf-object`, `x-facility-id`, modality cookies) verified on every page load.
2. Category & Sub-Category CSV Ingestion: Reads `Marianos_Category_URLs.csv` and
   maps every scraped item to its exact `category` and `sub_category`.
3. Pagination & Lazy-Scroll Handler: Iterates `?page=1..20` with viewport scroll
   hydration so all product cards and Kroger Atlas product payloads load completely.
4. Strict Approximate-Weight Exclusion: Excludes any product containing `approx` or
   `approximately` (case-insensitive) in `product_title` or `weight` (e.g., variable-weight
   deli/meat counter items).
5. Price-Per-Measure (`ppm`) Extraction Without Calculation: Extracts explicit shelf
   unit price strings (e.g., `$0.19/oz`, `$3.99/lb`, `$0.42/ct`) without calculating
   anything, while keeping `unit_price: ""` and `gupc: ""` strictly empty.
6. Volume vs. Digital Deal Classifier: Separates multi-buy / Mega Event offers
   (`Buy 2, Save $1.00 each`, `2 for $5.00`, `10/$10.00`) into `volume_deals_*` and
   Mariano's Weekly Digital Deals / Digital Coupons into `digital_deals_*`.
7. Canary & Anti-Blocking Detection: Detects Akamai Bot Manager (`_abck` challenge /
   HTTP 403 / Reference #18.*) and silent store resets; rotates browser context and
   retries with jittered backoff.
8. Checkpoint/Resume & Atomic Staging-to-Production Promotion: Writes intermediate
   records to `staging/`, updates checkpoint state, and promotes to `production/`
   ONLY when validation passes—preserving the last known good dataset on failure.
"""

from __future__ import annotations

import argparse
import csv
import json
import logging
import os
import re
import shutil
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from walmart_azure_scraper import (
    SCHEMA_FIELD_ORDER,
    extract_ppm_without_calculation,
    extract_weight,
    is_approximate_weight,
    normalize_price,
)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%SZ",
)
logger = logging.getLogger("marianos_azure_scraper")


@dataclass
class MarianosStoreContextConfig:
    zipcode: str = os.getenv("MARIANOS_ZIPCODE", "60031")
    facility_id: str = os.getenv("MARIANOS_FACILITY_ID", "53400029")
    store_name: str = os.getenv("MARIANOS_STORE_NAME", "Mariano's Gurnee #53400029")
    store_location: str = os.getenv(
        "MARIANOS_STORE_LOCATION", "6655 Grand Ave, Gurnee, IL 60031"
    )
    store_logo: str = os.getenv(
        "MARIANOS_STORE_LOGO",
        "https://www.marianos.com/content/v2/binary/image/marianos_svg_logo-1587579772255.svg",
    )
    modality_type: str = os.getenv("MARIANOS_MODALITY", "PICKUP")


@dataclass
class MarianosScraperConfig:
    csv_path: Path = Path(os.getenv("MARIANOS_CATEGORY_CSV", "Marianos_Category_URLs.csv"))
    staging_dir: Path = Path(os.getenv("SCRAPER_STAGING_DIR", "./data/staging/marianos"))
    production_dir: Path = Path(os.getenv("SCRAPER_PRODUCTION_DIR", "./data/production/marianos"))
    checkpoint_file: Path = Path(os.getenv("MARIANOS_CHECKPOINT_FILE", "./data/staging/marianos/checkpoint.json"))
    max_pages_per_subcategory: int = int(os.getenv("MARIANOS_MAX_PAGES", "15"))
    min_records_for_promotion: int = int(os.getenv("MARIANOS_MIN_RECORDS", "500"))
    max_concurrency: int = int(os.getenv("MARIANOS_CONCURRENCY", "2"))
    proxy_url: Optional[str] = os.getenv("AZURE_PROXY_URL", None)
    azure_blob_conn_str: Optional[str] = os.getenv("AZURE_STORAGE_CONNECTION_STRING", None)
    azure_blob_container: str = os.getenv("AZURE_BLOB_CONTAINER", "grocery-scraper-datasets")
    headless: bool = os.getenv("PLAYWRIGHT_HEADLESS", "true").lower() == "true"


@dataclass
class MarianosRunTelemetry:
    run_id: str
    started_at: str
    completed_at: Optional[str] = None
    store_context_verified_pages: int = 0
    store_context_relocks: int = 0
    blocked_or_captcha_events: int = 0
    approx_weight_filtered_count: int = 0
    duplicate_skipped_count: int = 0
    total_valid_records: int = 0
    categories_completed: int = 0
    category_counts: Dict[str, int] = field(default_factory=dict)
    promoted_to_production: bool = False
    failure_reason: Optional[str] = None


def build_marianos_22_field_record(raw: Dict[str, Any], store: MarianosStoreContextConfig) -> OrderedDict:
    ordered = OrderedDict()
    defaults = {
        "zipcode": str(store.zipcode),
        "store_name": str(store.store_name),
        "store_location": str(store.store_location),
        "store_logo": str(store.store_logo),
        "store_brand": str(raw.get("store_brand", "") or ""),
        "category": str(raw.get("category", "") or ""),
        "sub_category": str(raw.get("sub_category", "") or ""),
        "product_title": str(raw.get("product_title", "") or ""),
        "weight": str(raw.get("weight", "") or ""),
        "regular_price": str(raw.get("regular_price", "") or ""),
        "sale_price": str(raw.get("sale_price", "") or ""),
        "volume_deals_description": str(raw.get("volume_deals_description", "") or ""),
        "volume_deals_price": str(raw.get("volume_deals_price", "") or ""),
        "digital_deals_description": str(raw.get("digital_deals_description", "") or ""),
        "digital_deals_price": str(raw.get("digital_deals_price", "") or ""),
        "image_url": str(raw.get("image_url", "") or ""),
        "url": str(raw.get("url", "") or ""),
        "upc": str(raw.get("upc", "") or ""),
        "gupc": "",
        "ppm": extract_ppm_without_calculation(raw.get("ppm", "")),
        "unit_price": "",
        "crawl_date": str(raw.get("crawl_date") or datetime.now(timezone.utc).strftime("%Y-%m-%d")),
    }
    for key in SCHEMA_FIELD_ORDER:
        ordered[key] = defaults[key]
    return ordered


class MarianosAzureScraper:
    def __init__(self, store_cfg: MarianosStoreContextConfig, scraper_cfg: MarianosScraperConfig):
        self.store = store_cfg
        self.cfg = scraper_cfg
        self.run_id = datetime.now(timezone.utc).strftime("marianos_%Y%m%dT%H%M%SZ")
        self.telemetry = MarianosRunTelemetry(
            run_id=self.run_id,
            started_at=datetime.now(timezone.utc).isoformat(),
        )
        self.seen_dedup_keys: Set[Tuple[str, str, str, str]] = set()
        self.records: List[OrderedDict] = []

        self.cfg.staging_dir.mkdir(parents=True, exist_ok=True)
        self.cfg.production_dir.mkdir(parents=True, exist_ok=True)

    def load_category_targets(self) -> List[Dict[str, str]]:
        if not self.cfg.csv_path.exists():
            raise FileNotFoundError(f"Category CSV not found: {self.cfg.csv_path}")
        targets: List[Dict[str, str]] = []
        with self.cfg.csv_path.open("r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                cat = (row.get("category") or row.get("Category") or "").strip()
                sub = (row.get("sub_category") or row.get("Sub_Category") or row.get("subcategory") or "").strip()
                url = (row.get("url") or row.get("URL") or "").strip()
                if cat and sub and url:
                    targets.append({"category": cat, "sub_category": sub, "url": url})
        logger.info("Loaded %d Mariano's category/sub-category URLs from %s", len(targets), self.cfg.csv_path)
        return targets

    def ingest_raw_product(self, raw_item: Dict[str, Any]) -> bool:
        title = raw_item.get("product_title", "")
        weight = raw_item.get("weight", "")
        if is_approximate_weight(title, weight):
            self.telemetry.approx_weight_filtered_count += 1
            return False

        record = build_marianos_22_field_record(raw_item, self.store)
        if not record["product_title"] or not record["regular_price"]:
            return False

        dedup_key = (
            record["zipcode"],
            record["store_name"],
            record["upc"] or record["url"],
            record["sub_category"],
        )
        if dedup_key in self.seen_dedup_keys:
            self.telemetry.duplicate_skipped_count += 1
            return False

        self.seen_dedup_keys.add(dedup_key)
        self.records.append(record)
        cat = record["category"]
        self.telemetry.category_counts[cat] = self.telemetry.category_counts.get(cat, 0) + 1
        self.telemetry.total_valid_records = len(self.records)
        return True

    def promote_staging_to_production(self) -> bool:
        if len(self.records) < self.cfg.min_records_for_promotion:
            self.telemetry.failure_reason = (
                f"Staging dataset count ({len(self.records)}) below threshold ({self.cfg.min_records_for_promotion}). "
                "Preserving previous production dataset."
            )
            logger.error(self.telemetry.failure_reason)
            return False

        for idx, rec in enumerate(self.records):
            if tuple(rec.keys()) != SCHEMA_FIELD_ORDER:
                self.telemetry.failure_reason = f"Record #{idx} violated 22-field key ordering."
                logger.error(self.telemetry.failure_reason)
                return False
            if is_approximate_weight(rec["product_title"], rec["weight"]):
                self.telemetry.failure_reason = f"Record #{idx} contains prohibited approximate weight."
                logger.error(self.telemetry.failure_reason)
                return False
            if rec["gupc"] != "" or rec["unit_price"] != "":
                self.telemetry.failure_reason = f"Record #{idx} violated empty gupc/unit_price constraint."
                logger.error(self.telemetry.failure_reason)
                return False

        prod_latest = self.cfg.production_dir / "marianos_latest.json"
        prod_archive = self.cfg.production_dir / f"{self.run_id}.json"
        tmp_prod = self.cfg.production_dir / "marianos_latest.json.tmp"

        payload_text = json.dumps(self.records, indent=2, ensure_ascii=False)
        tmp_prod.write_text(payload_text, encoding="utf-8")
        tmp_prod.replace(prod_latest)
        shutil.copy2(prod_latest, prod_archive)

        self.telemetry.promoted_to_production = True
        self.telemetry.completed_at = datetime.now(timezone.utc).isoformat()
        logger.info(
            "ATOMIC PROMOTION COMPLETE: %d validated Mariano's records promoted to %s",
            len(self.records),
            prod_latest,
        )
        return True
