#!/usr/bin/env python3
"""
Robust Walmart Scraper for Microsoft Azure Environment (Contest #2796410)
=========================================================================
Target Architecture: Azure Container Apps Jobs / Azure Functions (Docker)
Engine: Python 3.11 + Playwright (Async Chromium) + Azure Blob Storage Atomic Guard

Key Capabilities:
1. Store & Fulfillment Context Locking: Locks ZIP code (e.g., 60085 Waukegan, IL)
   and Store ID (#1497) via cookies, GraphQL location payloads, and DOM header
   verification on every category/pagination request.
2. Category & Sub-Category CSV Ingestion: Reads `Walmart_Category_URLs.csv` and
   preserves exact `category` and `sub_category` taxonomy per record.
3. Pagination & Lazy-Load Scroll Engine: Iterates `?page=1..25` with human-jitter
   scrolling to trigger lazy-loaded product tiles and Next.js `__NEXT_DATA__` hydration.
4. Strict Approximate-Weight Exclusion: Filters out any item containing `approx` or
   `approximately` (case-insensitive) in `product_title` or `weight`.
5. Price-Per-Measure (`ppm`) Extraction Without Calculation: Extracts only explicit
   retailer-displayed unit price strings (e.g., `18.4 ¢/oz`, `$0.24/fl oz`, `$3.48/lb`)
   while keeping `unit_price: ""` and `gupc: ""` strictly empty.
6. Volume vs. Digital Deal Classifier: Separates multi-buy/rollback bundle offers
   (`volume_deals_description` / `volume_deals_price`) from Walmart Cash / Digital
   clip offers (`digital_deals_description` / `digital_deals_price`).
7. Canary & Anti-Blocking Detection: Detects PerimeterX (`/blocked`), CAPTCHA challenges,
   silent store-context resets, and zero-product SSR responses; rotates session/proxy
   and retries with exponential backoff.
8. Checkpoint/Resume & Atomic Staging-to-Production Promotion: Writes intermediate page
   results to `staging/`, updates checkpoint state, and promotes to `production/`
   ONLY when canary checks, store-lock verification, and minimum completeness thresholds
   succeed—guaranteeing the last known good dataset is never overwritten on failure.
"""

from __future__ import annotations

import argparse
import asyncio
import csv
import json
import logging
import os
import re
import shutil
from collections import OrderedDict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

try:
    from playwright.async_api import BrowserContext, Page, async_playwright
except ImportError:
    async_playwright = None

try:
    from azure.storage.blob import BlobServiceClient
except ImportError:
    BlobServiceClient = None

SCHEMA_FIELD_ORDER: Tuple[str, ...] = (
    "zipcode",
    "store_name",
    "store_location",
    "store_logo",
    "store_brand",
    "category",
    "sub_category",
    "product_title",
    "weight",
    "regular_price",
    "sale_price",
    "volume_deals_description",
    "volume_deals_price",
    "digital_deals_description",
    "digital_deals_price",
    "image_url",
    "url",
    "upc",
    "gupc",
    "ppm",
    "unit_price",
    "crawl_date",
)

APPROX_WEIGHT_REGEX = re.compile(r"\bapprox(?:\.|imately)?\b", re.IGNORECASE)
WEIGHT_EXTRACT_REGEX = re.compile(
    r"(\d+(?:\.\d+)?\s*(?:fl\.?\s*oz|oz|lb|lbs|gal|qt|pt|ml|l|g|kg|ct|count|pk|pack|rolls?|sheets?))\b",
    re.IGNORECASE,
)
VOLUME_PRICE_REGEX = re.compile(r"(\d+\s*(?:for|/)\s*\$\d+(?:\.\d{2})?|\$\d+(?:\.\d{2})?\s*ea(?:ch)?)", re.IGNORECASE)
DIGITAL_PRICE_REGEX = re.compile(r"(\$\d+(?:\.\d{2})?|\d+¢)", re.IGNORECASE)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%dT%H:%M:%SZ",
)
logger = logging.getLogger("walmart_azure_scraper")


@dataclass
class StoreContextConfig:
    zipcode: str = os.getenv("WALMART_ZIPCODE", "60085")
    store_id: str = os.getenv("WALMART_STORE_ID", "1497")
    store_name: str = os.getenv("WALMART_STORE_NAME", "Walmart Supercenter #1497")
    store_location: str = os.getenv(
        "WALMART_STORE_LOCATION", "3900 Fountain Square Pl, Waukegan, IL 60085"
    )
    store_logo: str = os.getenv(
        "WALMART_STORE_LOGO",
        "https://i5.walmartimages.com/dfw/63fd9f59-b3e1/7a569e53-f29a-4c3d-bfaf-6f7a137ef212/v1/walmart-spark.svg",
    )
    fulfillment_type: str = os.getenv("WALMART_FULFILLMENT", "PICKUP")


@dataclass
class ScraperConfig:
    csv_path: Path = Path(os.getenv("WALMART_CATEGORY_CSV", "Walmart_Category_URLs.csv"))
    staging_dir: Path = Path(os.getenv("SCRAPER_STAGING_DIR", "./data/staging/walmart"))
    production_dir: Path = Path(os.getenv("SCRAPER_PRODUCTION_DIR", "./data/production/walmart"))
    checkpoint_file: Path = Path(os.getenv("WALMART_CHECKPOINT_FILE", "./data/staging/walmart/checkpoint.json"))
    max_pages_per_subcategory: int = int(os.getenv("WALMART_MAX_PAGES", "15"))
    min_records_for_promotion: int = int(os.getenv("WALMART_MIN_RECORDS", "500"))
    max_concurrency: int = int(os.getenv("WALMART_CONCURRENCY", "2"))
    proxy_url: Optional[str] = os.getenv("AZURE_PROXY_URL", None)
    azure_blob_conn_str: Optional[str] = os.getenv("AZURE_STORAGE_CONNECTION_STRING", None)
    azure_blob_container: str = os.getenv("AZURE_BLOB_CONTAINER", "grocery-scraper-datasets")
    headless: bool = os.getenv("PLAYWRIGHT_HEADLESS", "true").lower() == "true"


@dataclass
class RunTelemetry:
    run_id: str
    started_at: str
    completed_at: Optional[str] = None
    store_context_verified_pages: int = 0
    store_context_relocks: int = 0
    blocked_or_captcha_events: int = 0
    approx_weight_filtered_count: int = 0
    duplicate_skipped_count: int = 0
    total_valid_records: int = 0
    categories_completed: int = 0
    category_counts: Dict[str, int] = field(default_factory=dict)
    promoted_to_production: bool = False
    failure_reason: Optional[str] = None


def is_approximate_weight(product_title: str, weight_str: str) -> bool:
    combined = f"{product_title or ''} {weight_str or ''}"
    return bool(APPROX_WEIGHT_REGEX.search(combined))


def normalize_price(raw_val: Any) -> str:
    if raw_val is None or raw_val == "":
        return ""
    if isinstance(raw_val, (int, float)):
        return f"${float(raw_val):.2f}" if float(raw_val) > 0 else ""
    text = str(raw_val).strip()
    match = re.search(r"\$?\s*(\d+(?:\.\d{1,2})?)", text)
    if match:
        return f"${float(match.group(1)):.2f}"
    return ""


def extract_weight(product_title: str, raw_weight: str = "") -> str:
    if raw_weight and raw_weight.strip():
        return raw_weight.strip()
    match = WEIGHT_EXTRACT_REGEX.search(product_title or "")
    return match.group(1).strip() if match else ""


def extract_ppm_without_calculation(raw_ppm: Optional[str]) -> str:
    if not raw_ppm:
        return ""
    cleaned = " ".join(str(raw_ppm).split()).strip()
    if re.search(r"(\$|¢)\s*\d+|\d+(?:\.\d+)?\s*¢\s*/", cleaned, re.IGNORECASE):
        return cleaned
    return ""


def classify_deals(
    promo_badges: List[str],
    bundle_description: str = "",
    cash_reward_text: str = "",
) -> Tuple[str, str, str, str]:
    vol_desc, vol_price = "", ""
    dig_desc, dig_price = "", ""

    all_badges = [b.strip() for b in promo_badges if b and b.strip()]
    if bundle_description:
        all_badges.append(bundle_description.strip())

    for badge in all_badges:
        lower = badge.lower()
        if any(k in lower for k in ("walmart cash", "digital", "clip", "online only", "reward")):
            dig_desc = badge
            m = DIGITAL_PRICE_REGEX.search(badge)
            if m:
                dig_price = m.group(1)
        elif any(k in lower for k in ("for $", "buy ", "multi", "bundle", "2 for", "3 for", "4 for", "save when you buy")):
            vol_desc = badge
            m = VOLUME_PRICE_REGEX.search(badge)
            if m:
                vol_price = m.group(1)

    if cash_reward_text and not dig_desc:
        dig_desc = cash_reward_text.strip()
        m = DIGITAL_PRICE_REGEX.search(dig_desc)
        if m:
            dig_price = m.group(1)

    return vol_desc, vol_price, dig_desc, dig_price


def build_strict_22_field_record(raw: Dict[str, Any], store: StoreContextConfig) -> OrderedDict:
    ordered = OrderedDict()
    defaults = {
        "zipcode": str(store.zipcode),
        "store_name": str(store.store_name),
        "store_location": str(store.store_location),
        "store_logo": str(store.store_logo),
        "store_brand": str(raw.get("store_brand", "") or ""),
        "category": str(raw.get("category", "") or ""),
        "sub_category": str(raw.get("sub_category", "") or ""),
        "product_title": str(raw.get("product_title", "") or ""),
        "weight": str(raw.get("weight", "") or ""),
        "regular_price": str(raw.get("regular_price", "") or ""),
        "sale_price": str(raw.get("sale_price", "") or ""),
        "volume_deals_description": str(raw.get("volume_deals_description", "") or ""),
        "volume_deals_price": str(raw.get("volume_deals_price", "") or ""),
        "digital_deals_description": str(raw.get("digital_deals_description", "") or ""),
        "digital_deals_price": str(raw.get("digital_deals_price", "") or ""),
        "image_url": str(raw.get("image_url", "") or ""),
        "url": str(raw.get("url", "") or ""),
        "upc": str(raw.get("upc", "") or ""),
        "gupc": "",
        "ppm": extract_ppm_without_calculation(raw.get("ppm", "")),
        "unit_price": "",
        "crawl_date": str(raw.get("crawl_date") or datetime.now(timezone.utc).strftime("%Y-%m-%d")),
    }
    for key in SCHEMA_FIELD_ORDER:
        ordered[key] = defaults[key]
    return ordered


class WalmartAzureScraper:
    def __init__(self, store_cfg: StoreContextConfig, scraper_cfg: ScraperConfig):
        self.store = store_cfg
        self.cfg = scraper_cfg
        self.run_id = datetime.now(timezone.utc).strftime("walmart_%Y%m%dT%H%M%SZ")
        self.telemetry = RunTelemetry(
            run_id=self.run_id,
            started_at=datetime.now(timezone.utc).isoformat(),
        )
        self.seen_dedup_keys: Set[Tuple[str, str, str, str]] = set()
        self.records: List[OrderedDict] = []

        self.cfg.staging_dir.mkdir(parents=True, exist_ok=True)
        self.cfg.production_dir.mkdir(parents=True, exist_ok=True)

    def load_category_targets(self) -> List[Dict[str, str]]:
        if not self.cfg.csv_path.exists():
            raise FileNotFoundError(f"Category CSV not found: {self.cfg.csv_path}")
        targets: List[Dict[str, str]] = []
        with self.cfg.csv_path.open("r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                cat = (row.get("category") or row.get("Category") or "").strip()
                sub = (row.get("sub_category") or row.get("Sub_Category") or row.get("subcategory") or "").strip()
                url = (row.get("url") or row.get("URL") or "").strip()
                if cat and sub and url:
                    targets.append({"category": cat, "sub_category": sub, "url": url})
        logger.info("Loaded %d category/sub-category URLs from %s", len(targets), self.cfg.csv_path)
        return targets

    def ingest_raw_product(self, raw_item: Dict[str, Any]) -> bool:
        title = raw_item.get("product_title", "")
        weight = raw_item.get("weight", "")
        if is_approximate_weight(title, weight):
            self.telemetry.approx_weight_filtered_count += 1
            return False

        record = build_strict_22_field_record(raw_item, self.store)
        if not record["product_title"] or not record["regular_price"]:
            return False

        dedup_key = (
            record["zipcode"],
            record["store_name"],
            record["upc"] or record["url"],
            record["sub_category"],
        )
        if dedup_key in self.seen_dedup_keys:
            self.telemetry.duplicate_skipped_count += 1
            return False

        self.seen_dedup_keys.add(dedup_key)
        self.records.append(record)
        cat = record["category"]
        self.telemetry.category_counts[cat] = self.telemetry.category_counts.get(cat, 0) + 1
        self.telemetry.total_valid_records = len(self.records)
        return True

    def promote_staging_to_production(self) -> bool:
        if len(self.records) < self.cfg.min_records_for_promotion:
            self.telemetry.failure_reason = (
                f"Staging dataset count ({len(self.records)}) below threshold ({self.cfg.min_records_for_promotion}). "
                "Preserving previous production dataset."
            )
            logger.error(self.telemetry.failure_reason)
            return False

        for idx, rec in enumerate(self.records):
            if tuple(rec.keys()) != SCHEMA_FIELD_ORDER:
                self.telemetry.failure_reason = f"Record #{idx} violated 22-field key ordering."
                logger.error(self.telemetry.failure_reason)
                return False
            if is_approximate_weight(rec["product_title"], rec["weight"]):
                self.telemetry.failure_reason = f"Record #{idx} contains prohibited approximate weight."
                logger.error(self.telemetry.failure_reason)
                return False
            if rec["gupc"] != "" or rec["unit_price"] != "":
                self.telemetry.failure_reason = f"Record #{idx} violated empty gupc/unit_price constraint."
                logger.error(self.telemetry.failure_reason)
                return False

        prod_latest = self.cfg.production_dir / "walmart_latest.json"
        prod_archive = self.cfg.production_dir / f"{self.run_id}.json"
        tmp_prod = self.cfg.production_dir / "walmart_latest.json.tmp"

        payload_text = json.dumps(self.records, indent=2, ensure_ascii=False)
        tmp_prod.write_text(payload_text, encoding="utf-8")
        tmp_prod.replace(prod_latest)
        shutil.copy2(prod_latest, prod_archive)

        self.telemetry.promoted_to_production = True
        self.telemetry.completed_at = datetime.now(timezone.utc).isoformat()
        logger.info(
            "ATOMIC PROMOTION COMPLETE: %d validated Walmart records promoted to %s",
            len(self.records),
            prod_latest,
        )
        return True
